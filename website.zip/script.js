var navLinks = document.getelementById("navLinks");
      function showMenu() {
        
        navLinks.style.right = "0";  
        console.log(navLinks)
      }
      
      function hideMenu() {
        navLinks.style.right = "-200px";
      }